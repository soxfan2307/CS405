// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
// Original function: encrypts or decrypts a source string using the provided key
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for performance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string character by character
    for (size_t i = 0; i < source_length; ++i)
    { // TODO: Change the next line from output[i] = source[i]
        // Transform each character based on an XOR of the key modded constrained to key length using a mod
        output[i] = source[i] ^ key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    std::string file_text;

    // Open the file
    std::ifstream file(filename);
    if (file.is_open()) {
        // Read the entire file content into a string
        std::stringstream buffer;
        buffer << file.rdbuf();
        file_text = buffer.str();
        file.close();
    }

    return file_text;
}

// Extract the student name from the provided string data
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline
    size_t pos = string_data.find('\n');
    // Check if a newline was found
    if (pos != std::string::npos)
    {
        // Extract the substring before the newline as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

// TODO: Implement saving data to a file in the specified format
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Open the file for writing
    std::ofstream file(filename);
    if (file.is_open()) {
        // Write student name, timestamp, key, and data to the file
        file << student_name << "\n";
        std::time_t now = std::time(nullptr);
        struct std::tm timeinfo;
        localtime_s(&timeinfo, &now);
        char buffer[80];
        strftime(buffer, sizeof(buffer), "%Y-%m-%d", &timeinfo);
        file << buffer << "\n";
        file << key << "\n";
        file << data;
        file.close();
    }
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Define filenames and parameters
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // Get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // Encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save encrypted_string to a file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save decrypted_string to a file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // Students submit input file, encrypted file, decrypted file, source code file, and key used
    return 0;
}
